README for Final project of group 9 (ananya15, kijungk3, kadinas2, muyey2)

The project library for this project is the folder final_project. Within this library the toplevel layout, schematic, and extracted layout can be found as the cellview 'FinalDesign'.

There is only one netlist for this top level design, which is final.cir. This contains the extracted netlist and the second testbench, which we used to determine values for our report.


